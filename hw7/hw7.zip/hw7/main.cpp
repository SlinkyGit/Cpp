

#include <iostream>
#include <filesystem> // For filesystem operations
#include <string>
#include "FileSearch.h"  // Include your FileSearch header


namespace fs = std::filesystem;

// int main(int argc, char* argv[]) {
//     if (argc < 2) {
//         std::cerr << "Usage: " << argv[0] << " <target string> [directory]\n";
//         return 1; // Exit with error if the target is not provided
//     }

//     std::string target = argv[1]; // The target string to search for
//     fs::path dir = argc > 2 ? fs::path(argv[2]) : fs::current_path(); // Directory path or current directory

//     // Output the initialization information
//     std::cout << "!---- Search Started ----!\n";
//     std::cout << "Target Folder: " << dir << '\n';
//     std::cout << "Target Text: " << target << '\n';
//     unsigned int numThreads = std::thread::hardware_concurrency();
//     if (numThreads < 2) numThreads = 2; // Ensuring at least 2 threads
//     std::cout << "Using a Pool of " << numThreads << " threads to search.\n";

//     // Further implementation will go here

//     std::cout << "!---- Search Complete ----!\n";
//     return 0; // Normal exit
// }

// Test FileSearch Basic:


int main(int argc, char* argv[]) {
    if (argc < 2) {
        std::cerr << "Usage: " << argv[0] << " <target string> [directory]\n";
        return 1;
    }

    std::string target = argv[1];
    fs::path dir = argc > 2 ? fs::path(argv[2]) : fs::current_path();

    std::cout << "!---- Search Started ----!\n";
    std::cout << "Target Folder: " << dir << '\n';
    std::cout << "Target Text: " << target << '\n';
    unsigned int numThreads = std::thread::hardware_concurrency();
    if (numThreads < 2) numThreads = 2;
    std::cout << "Using a Pool of " << numThreads << " threads to search.\n";

    // Create FileSearch object and run it
    FileSearch fileSearch(target, dir);
    fileSearch.run();

    std::cout << "!---- Search Complete ----!\n";
    return 0;
}
