#ifndef _THREAD_POOL_H_
#define _THREAD_POOL_H_

#include <thread>
#include <mutex>
#include <condition_variable>
#include <queue>
#include <string>
#include "task.h" // Make sure task.h is correctly defined to accept a std::string target.

class threadPool {
private:
    int numberOfThreads;
    std::thread** myThreads;
    bool* status;
    bool done;
    std::condition_variable needsWork;
    std::mutex queueLock;
    std::queue<task*>* toDO;
    std::string targetString;  // To store the search string.
    std::mutex& filesQueueMutex;
    std::condition_variable& filesQueueCondVar;
    std::queue<std::string>& filesQueue;
    bool& producerDone;

public:
    threadPool(const std::string& target, std::queue<std::string>& fileQueue,
               std::mutex& queueMutex, std::condition_variable& queueCondVar, bool& done);
    ~threadPool();
    void addWork(task* t);
    void start();
    void shutdown();

private:
    void workerThread(int statusID);
    void stop();
};

#endif // _THREAD_POOL_H_
