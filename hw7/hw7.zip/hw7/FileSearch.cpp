// FileSearch.cpp
#include "FileSearch.h"
#include <iostream>
#include <vector>
#include <string>
#include <filesystem>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <fstream>
#include <sstream>

FileSearch::FileSearch(const std::string& target, const std::filesystem::path& dir)
    : target(target), dir(dir) {}

// void FileSearch::run() {
//     std::thread producer_thread(&FileSearch::producer, this);
//     producer_thread.join();
// }

// void FileSearch::run() {
//     std::thread producer_thread(&FileSearch::producer, this);
//     unsigned int numThreads = std::max(2u, std::thread::hardware_concurrency());
//     for (unsigned int i = 0; i < numThreads; ++i) {
//         workers.emplace_back(&FileSearch::worker, this);
//     }
//     producer_thread.join();
//     all_files_listed = true;
//     cv_queue.notify_all();
//     for (auto& worker : workers) {
//         worker.join();
//     }
// }

void FileSearch::run() {
    std::thread producer_thread(&FileSearch::producer, this);

    unsigned int numThreads = std::max(2u, std::thread::hardware_concurrency());
    workers.reserve(numThreads);  // Reserve to prevent reallocation affecting threads
    for (unsigned int i = 0; i < numThreads; ++i) {
        workers.emplace_back(&FileSearch::worker, this);
    }

    producer_thread.join();
    for (auto& worker : workers) {
        worker.join();
    }
}

// void FileSearch::worker() {
//     std::unique_lock<std::mutex> lock(queue_mutex, std::defer_lock);
//     while (true) {
//         lock.lock();
//         cv_queue.wait(lock, [this]{ return !file_queue.empty() || all_files_listed; });
//         if (file_queue.empty()) break;
//         auto file = file_queue.front();
//         file_queue.pop();
//         lock.unlock();
//         std::ifstream file_stream(file);
//         std::string line;
//         unsigned int line_number = 0;
//         while (getline(file_stream, line)) {
//             line_number++;
//             if (line.find(target) != std::string::npos) {
//                 std::lock_guard<std::mutex> print_lock(mutex_files);  // Assuming mutex_files is used for output synchronization
//                 std::cout << "Thread " << std::this_thread::get_id() << " found a match.\n";
//                 std::cout << "File: \"" << file << "\"\n";
//                 std::cout << "Line " << line_number << ": " << line << '\n';
//                 std::cout << "----------\n";
//             }
//         }
//     }
// }
// void FileSearch::worker() {
//     std::cout << "Thread " << std::this_thread::get_id() << " starting.\n";
//     std::unique_lock<std::mutex> lock(queue_mutex, std::defer_lock);
//     while (true) {
//         lock.lock();
//         std::cout << "Thread " << std::this_thread::get_id() << " locked and waiting.\n";
//         if (file_queue.empty()) {
//             if (all_files_listed) {
//                 std::cout << "Thread " << std::this_thread::get_id() << " unlocking and exiting because all files are listed and queue is empty.\n";
//                 lock.unlock();
//                 break;
//             }
//             cv_queue.wait(lock, [this]{ return !file_queue.empty() || all_files_listed; });
//         }

//         if (file_queue.empty()) {
//             std::cout << "Thread " << std::this_thread::get_id() << " unlocking and exiting because queue is empty after wait.\n";
//             lock.unlock();
//             break;
//         }

//         std::filesystem::path file_path = file_queue.front();
//         file_queue.pop();
//         lock.unlock();
//         std::cout << "Thread " << std::this_thread::get_id() << " processing file: " << file_path << ".\n";

//         std::ifstream file_stream(file_path);
//         if (!file_stream.is_open()) {
//             std::cerr << "Thread " << std::this_thread::get_id() << " failed to open file: " << file_path << std::endl;
//             continue;
//         }
//         std::string line;
//         unsigned int line_number = 0;
//         while (getline(file_stream, line)) {
//             line_number++;
//             if (line.find(target) != std::string::npos) {
//                 std::lock_guard<std::mutex> print_lock(mutex_files);
//                 std::cout << "Thread " << std::this_thread::get_id() << " found a match in " << file_path << " at line " << line_number << ".\n";
//             }
//         }
//     }
// }

void FileSearch::worker() {
    while (true) {
        std::filesystem::path file_path;
        {
            std::unique_lock<std::mutex> lock(queue_mutex);
            cv_queue.wait(lock, [this]{ return !file_queue.empty() || all_files_listed; });
            if (file_queue.empty()) break;
            file_path = file_queue.front();
            file_queue.pop();
        }

        std::ifstream file_stream(file_path);
        if (!file_stream.is_open()) {
            std::cerr << "Failed to open file: " << file_path << std::endl;
            continue;
        }

        std::string line;
        unsigned int line_number = 0;
        while (getline(file_stream, line)) {
            line_number++;
            if (line.find(target) != std::string::npos) {
                std::lock_guard<std::mutex> print_lock(mutex_files);
                std::cout << "Thread " << std::this_thread::get_id() << " found a match in " << file_path << " at line " << line_number << ".\n";
            }
        }
    }
}



// void FileSearch::producer() {
//     files = find_files(dir);
//     // Output for debugging
//     for (const auto& file : files) {
//         std::cout << "Found file: " << file << '\n';
//     }
// }

void FileSearch::producer() {
    files = find_files(dir);
    // Output for debugging
    for (const auto& file : files) {
        std::cout << "Found file: " << file << '\n';
        std::unique_lock<std::mutex> lock(queue_mutex);
        file_queue.push(file);
    }

    // Notify after adding all files
    all_files_listed = true;
    cv_queue.notify_all();
}

// ref -> https://stackoverflow.com/questions/67273/how-do-you-iterate-through-every-file-directory-recursively-in-standard-c
std::vector<std::filesystem::path> FileSearch::find_files(const std::filesystem::path& dir) {
    std::vector<std::filesystem::path> local_files;
    std::string extensions[] = {".cc", ".c", ".cpp", ".h", ".hpp", ".pl", ".sh", ".py", ".txt"};
    for (const auto& entry : std::filesystem::recursive_directory_iterator(dir)) {
        if (std::filesystem::is_regular_file(entry.status()) &&
            std::find(std::begin(extensions), std::end(extensions), entry.path().extension()) != std::end(extensions)) {
            local_files.push_back(entry.path());
        }
    }
    return local_files;
}
