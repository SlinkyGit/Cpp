// FileSearch.h
#ifndef FILE_SEARCH_H
#define FILE_SEARCH_H

#include <vector>
#include <string>
#include <filesystem>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <queue>

class FileSearch {
public:
    FileSearch(const std::string& target, const std::filesystem::path& dir);
    void run();

private:
    void producer();

    void worker();
    std::vector<std::filesystem::path> find_files(const std::filesystem::path& dir);

    std::mutex mutex_files;

    std::string target;
    std::filesystem::path dir;
    std::vector<std::filesystem::path> files;
    std::queue<std::filesystem::path> file_queue;
    std::vector<std::thread> workers;
    std::mutex queue_mutex;
    std::condition_variable cv_queue;
    bool all_files_listed = false;
};

#endif // FILE_SEARCH_H
