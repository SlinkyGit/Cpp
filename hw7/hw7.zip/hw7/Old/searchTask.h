#ifndef _SEARCH_TASK_H_
#define _SEARCH_TASK_H_
#include "task.h"
#include <string>
#include <queue>
#include <iostream>

class searchTask : public task {
private:
    std::string filePath;
    std::string searchText;

public:
    // Constructor taking file path and text to search
    searchTask(const std::string& file, const std::string& text) : filePath(file), searchText(text) {}

    // Override the runTask method from task
    std::queue<task*>* runTask() override;

    // Destructor
    virtual ~searchTask() {}
};
#endif
