#include "searchTask.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <thread>
#include <mutex>

// std::queue<task*>* searchTask::runTask() {
//     std::queue<task*>* resultQueue = new std::queue<task*>();
//     std::ifstream file(filePath);
//     std::string line;
//     int lineCount = 1;
//     if (file.is_open()) {
//         while (getline(file, line)) {
//             if (line.find(searchText) != std::string::npos) {
//                 std::cout << "Match found in " << filePath << " at line " << lineCount << ": " << line << std::endl;
//             }
//             lineCount++;
//         }
//         file.close();
//     } else {
//         std::cerr << "Failed to open file: " << filePath << std::endl;
//     }
//     return resultQueue; // Empty as no further tasks are generated.
// }

// std::queue<task*>* searchTask::runTask() {
//     std::queue<task*>* resultQueue = new std::queue<task*>();
//     std::ifstream file(filePath);
//     std::string line;
//     int lineCount = 1;

//     if (file.is_open()) {
//         while (getline(file, line)) {
//             if (line.find(searchText) != std::string::npos) {
//                 std::cout << "Thread " << std::this_thread::get_id() << " found a match." << std::endl;
//                 std::cout << "File: \"" << filePath << "\"" << std::endl;
//                 std::cout << "Line " << lineCount << ": " << line << std::endl;
//                 std::cout << "----------" << std::endl;
//             }
//             lineCount++;
//         }
//         file.close();
//     } else {
//         std::cerr << "Failed to open file: " << filePath << std::endl;
//     }
//     return resultQueue; // Empty as no further tasks are generated.
// }

std::queue<task*>* searchTask::runTask() {
    std::queue<task*>* resultQueue = new std::queue<task*>();
    std::ifstream file(filePath);
    std::string line;
    int lineCount = 1;

    if (file.is_open()) {
        std::cout << "Searching in file: " << filePath << std::endl;  // Debug file opened
        while (getline(file, line)) {
            if (line.find(searchText) != std::string::npos) {
                std::cout << "Thread " << std::this_thread::get_id() << " found a match in " << filePath
                          << " at line " << lineCount << ": " << line << std::endl;
            }
            lineCount++;
        }
        file.close();
    } else {
        std::cerr << "Failed to open file: " << filePath << std::endl;
    }
    return resultQueue; // Empty as no further tasks are generated.
}