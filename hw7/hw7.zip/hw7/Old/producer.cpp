#include "producer.h"
#include <iostream>
#include <thread>

Producer::Producer(const std::string& dir, std::queue<std::string>& fileQueue,
                   std::mutex& queueMutex, std::condition_variable& queueCondVar, bool& done)
    : directory(dir), filesQueue(fileQueue), filesQueueMutex(queueMutex),
      filesQueueCondVar(queueCondVar), producerDone(done) {}

void Producer::operator()() {
    searchDirectory(directory);
    producerDone = true;
    filesQueueCondVar.notify_all();  // Notify all threads that producer has finished
}

// void Producer::searchDirectory(const std::filesystem::path& path) {
//     for (const auto& entry : std::filesystem::recursive_directory_iterator(path)) {
//         if (entry.is_regular_file()) {
//             std::string ext = entry.path().extension().string();
//             if (ext == ".cc" || ext == ".c" || ext == ".cpp" || ext == ".h" ||
//                 ext == ".hpp" || ext == ".pl" || ext == ".sh" || ext == ".py" || ext == ".txt") {
//                 std::unique_lock<std::mutex> lock(filesQueueMutex);
//                 filesQueue.push(entry.path().string());
//                 filesQueueCondVar.notify_one();
//             }
//         }
//     }
// }

void Producer::searchDirectory(const std::filesystem::path& path) {
    for(const auto& entry : std::filesystem::recursive_directory_iterator(path)){
        if (entry.is_regular_file()) {
            std::string ext = entry.path().extension().string();
            if (ext == ".cc" || ext == ".c" || ext == ".cpp" || ext == ".h" ||
                ext == ".hpp" || ext == ".pl" || ext == ".sh" || ext == ".py" || ext == ".txt") {
                std::unique_lock<std::mutex> lock(filesQueueMutex);
                std::cout << "Enqueuing file: " << entry.path() << std::endl;  // Debugging output
                filesQueue.push(entry.path().string());
                filesQueueCondVar.notify_one();
            }
        }
    }
}