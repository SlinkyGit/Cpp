#include "threadPool.h"
#include <iostream>
#include "searchTask.h" // Ensure this header is properly defined
#include <thread>

threadPool::threadPool(const std::string& target, std::queue<std::string>& fileQueue,
                       std::mutex& queueMutex, std::condition_variable& queueCondVar, bool& done)
    : targetString(target), filesQueue(fileQueue), filesQueueMutex(queueMutex),
      filesQueueCondVar(queueCondVar), producerDone(done) {
    numberOfThreads = std::thread::hardware_concurrency();
    numberOfThreads = (numberOfThreads < 2) ? 2 : numberOfThreads;  // Ensure at least 2 threads.
    myThreads = new std::thread*[numberOfThreads];
    status = new bool[numberOfThreads];
    toDO = new std::queue<task*>();
}

// threadPool::threadPool(const std::string& target, std::queue<std::string>& fileQueue,
//                        std::mutex& queueMutex, std::condition_variable& queueCondVar, bool& done)
//     : targetString(target), filesQueue(fileQueue), filesQueueMutex(queueMutex),
//       filesQueueCondVar(queueCondVar), producerDone(done) {
//     numberOfThreads = std::thread::hardware_concurrency();
//     numberOfThreads = (numberOfThreads < 2) ? 2 : numberOfThreads;  // Ensure at least 2 threads.
//     myThreads = new std::thread*[numberOfThreads];
//     status = new bool[numberOfReaders];
//     toDO = new std::queue<task*>();
//     done = false;
// }

threadPool::~threadPool(){
    shutdown(); // Clean up threads on destruction
    delete[] myThreads;
    delete[] status;
    delete toDO;
}

void threadPool::addWork(task* t) {
    std::lock_guard<std::mutex> lk(queueLock);
    toDO->push(t);
    needsWork.notify_one(); // Notify one waiting thread
}

void threadPool::start() {
    for (int i = 0; i < numberOfThreads; i++) {
        myThreads[i] = new std::thread(&threadPool::workerThread, this, i);
    }
    // Consider adding a short delay or synchronization mechanism here to ensure all threads are ready
    std::this_thread::sleep_for(std::chrono::milliseconds(500)); // Simple but not always recommended
}
// void threadPool::shutdown() {
//     done = true; // Signal all threads to stop
//     needsWork.notify_all(); // Wake up all threads
//     for (int i = 0; i < numberOfThreads; i++) {
//         if (myThreads[i]->joinable()) {
//             myThreads[i]->join(); // Ensure all threads finish cleanly
//             delete myThreads[i]; // Clean up thread pointers
//         }
//     }
// }
void threadPool::shutdown() {
    {
        std::lock_guard<std::mutex> guard(queueLock);
        done = true;  // Signal all threads to complete
    }
    needsWork.notify_all();  // Wake up all threads to re-check conditions
    for (int i = 0; i < numberOfThreads; i++) {
        if (myThreads[i]->joinable()) {
            myThreads[i]->join();  // Ensure all threads finish cleanly
        }
        delete myThreads[i];  // Safe to delete after join
    }
}

void threadPool::workerThread(int statusID) {
    while (!done) {
        task* t = nullptr;
        {
            std::unique_lock<std::mutex> lk(queueLock);
            needsWork.wait(lk, [&] { return !toDO->empty() || done; });
            if (done && toDO->empty()) break; // Stop if done and no tasks left
            t = toDO->front();
            toDO->pop();
        }
        if (t != nullptr) {
            std::queue<task*>* more = t->runTask();
            if (more != nullptr) {
                while (!more->empty()) {
                    addWork(more->front());
                    more->pop();
                }
                delete more; // Clean up after yourself
            }
            delete t; // Clean up the task now that it's done
        }
    }
}

// void threadPool::workerThread(int statusID) {
//     std::cout << "Thread " << statusID << " started." << std::endl;  // Debug start of thread
//     while (!done) {
//         task* t = nullptr;
//         {
//             std::unique_lock<std::mutex> lk(queueLock);
//             needsWork.wait(lk, [&] { return !toDO->empty() || done; });
//             if (done && toDO->empty()) break;
//             t = toDO->front();
//             toDO->pop();
//         }
//         if (t != nullptr) {
//             std::cout << "Thread " << statusID << " is processing a file." << std::endl;  // Debug task processing
//             std::queue<task*>* more = t->runTask();
//             while (!more->empty()) {
//                 addWork(more->front());
//                 more->pop();
//             }
//             delete more;
//             delete t;
//         }
//     }
//     std::cout << "Thread " << statusID << " is exiting." << std::endl;  // Debug end of thread
// }


// void threadPool::workerThread(int statusID) {
//     std::cout << "Thread " << statusID << " started." << std::endl;
//     while (true) {
//         std::unique_lock<std::mutex> lk(queueLock);
//         needsWork.wait(lk, [this] { return !toDO->empty() || done; });
        
//         if (done && toDO->empty()) {
//             lk.unlock();  // Release the lock before breaking to avoid deadlock on notify_all in shutdown.
//             break;  // Exit loop if done and no tasks are left.
//         }

//         task* t = nullptr;
//         if (!toDO->empty()) {
//             t = toDO->front();
//             toDO->pop();
//             lk.unlock();  // Unlock as soon as the task is popped.
            
//             std::cout << "Thread " << statusID << " is processing a file." << std::endl;
//             t->runTask();
//             delete t;  // Clean up the task
//         }
//     }
//     std::cout << "Thread " << statusID << " is exiting." << std::endl;
// }


// void threadPool::workerThread(int statusID) {
//     std::cout << "Thread " << statusID << " started." << std::endl;
//     while (true) {
//         std::unique_lock<std::mutex> lk(queueLock);
//         // Wait until there is work to do or the producer has marked done
//         needsWork.wait(lk, [this] { return !toDO->empty() || done; });
//         if (toDO->empty() && done) {
//             break;  // No more tasks and producer is done
//         }
//         task* t = toDO->front();  // Get the task from the queue
//         toDO->pop();
//         lk.unlock();  // Unlock as soon as possible
//         if (t) {
//             t->runTask();  // Execute the task
//             delete t;  // Free task memory
//         }
//     }
//     std::cout << "Thread " << statusID << " is exiting." << std::endl;
// }
