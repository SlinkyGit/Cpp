#ifndef PRODUCER_H_
#define PRODUCER_H_

#include <string>
#include <filesystem>
#include <queue>
#include <mutex>
#include <condition_variable>

class Producer {
public:
    Producer(const std::string& dir, std::queue<std::string>& fileQueue,
             std::mutex& queueMutex, std::condition_variable& queueCondVar, bool& done);
    void operator()();

private:
    std::string directory;
    std::queue<std::string>& filesQueue;
    std::mutex& filesQueueMutex;
    std::condition_variable& filesQueueCondVar;
    bool& producerDone;
    void searchDirectory(const std::filesystem::path& path);
};

#endif  // PRODUCER_H_
